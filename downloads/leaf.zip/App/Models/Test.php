<?php
namespace App\Models;

new \Leaf\Database;

class Test extends \Leaf\Model {
	protected $table = "users";
}
