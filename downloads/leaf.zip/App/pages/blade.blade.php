<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Blade Demo</title>
</head>

<body>
	<h1>This is a blade View</h1>
	<p>{{ $data }}</p>
</body>

</html>