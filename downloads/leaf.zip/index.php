<?php
require_once __DIR__ . '/vendor/autoload.php';

$app = new Leaf\App;

$app->set404();
$app->db->connect("host", "username", "password", "dbname");

$app->get('/book/{id}', function ($id) use ($app) {
	$app->response->respond(["id" => $id]);
});

$app->post('/books/add', function () use ($app) {
	$title = $app->request->get('title');
	$app->db->add("books", ["title" => $title], ["title"]);
	$app->response->respond([
		"books" => $app->db->select("books")->fetchAll()
	]);
});
