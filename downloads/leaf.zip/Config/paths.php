<?php
const paths = [
	"views" => "App/pages/",
	"storage" => "storage/",
	"controllers" => "App/Controllers/",
	"models" => "App/Models/"
];
