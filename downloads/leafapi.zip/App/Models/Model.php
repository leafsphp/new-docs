<?php
namespace App\Models;

new \Leaf\Database;

/**
 * Base Model
 */
class Model extends \Leaf\Model {}
