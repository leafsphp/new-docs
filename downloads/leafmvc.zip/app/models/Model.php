<?php
namespace App\Models;

use Leaf\Core\Model as CoreModel;

use Leaf\Core\Database;
new Database();

class Model extends CoreModel{
	
}