<nav class="wynter header bg-green-400">
	<div class="wynter header-row">
		<a href="/" class="wynter title nav-link">Leaf MVC</a>
		<div class="wynter spacer"></div>
		<a href="#" class="wynter nav-link">Home</a>
	</div>
</nav>